import { ArrowBackOutlined } from "@material-ui/icons";
import { Link, useLocation } from "react-router-dom";
import "./watch.scss";

export default function Watch() {
  const location = useLocation();
  console.log(location);
  const {picture} = location.state;
  
  return (
    <div className="watch">
      <Link to="/">
        <div className="back">
          <ArrowBackOutlined />
          Home
        </div>
      </Link>
      {/* <div className="video">
        <iframe className="iframe" allow="autoplay; gyroscope;" allowfullscreen height="100%" referrerpolicy="strict-origin" src="https://www.kapwing.com/e/62208387f6cc090114791b22"  title="Embedded content made on Kapwing" width="100%"></iframe>
      </div> */}
      <video className="video" autoPlay progress controls src={picture.video} />
    </div>
  );
}