import { Link, useLocation } from "react-router-dom";
import "./user.css";
import { Publish } from "@material-ui/icons";


export default function User() {
  const location = useLocation();
  console.log(location)
  const{user} = location.state;
  return (
      <>
        
    <div className="product">
      <div className="productTitleContainer">
        <h1 className="productTitle">User</h1>
        <Link to="/newproduct">
          <button className="productAddButton">Create</button>
        </Link>
      </div>
      <div className="productTop">
        <div className="productTopRight">
          <div className="productInfoTop">
            <img src={user.img} alt="" className="productInfoImg" />
            <span className="productName">{user.username}</span>
          </div>
          <div className="productInfoBottom">
            <div className="productInfoItem">
              <span className="productInfoKey">id:</span>
              <span className="productInfoValue">{user._id}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">username:</span>
              <span className="productInfoValue">{user.username}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">email:</span>
              <span className="productInfoValue">{user.email}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">isAdmin:</span>
              <span className="productInfoValue">{user.isAdmin.toString()}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="productBottom">
        <form className="productForm">
          <div className="productFormLeft">
            <label>User Name</label>
            <input type="text" placeholder={user.username} />
            <label>Email</label>
            <input type="text" placeholder={user.email} />
            <label>isAdmin</label>
            <input type="text" placeholder={user.isAdmin.toString()} />
            
          </div>
          <div className="productFormRight">
            <div className="productUpload">
              <img
                src={user.img}
                alt=""
                className="productUploadImg"
              />
              <label for="file">
                <Publish />
              </label>
              <input type="file" id="file" style={{ display: "none" }} />
            </div>
            <button className="productButton">Update</button>
          </div>
        </form>
      </div>
    </div>
   
    </>
  );
}