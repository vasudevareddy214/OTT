import React, { useContext } from "react";
import "./topbar.css";
import { NotificationsNone, Language, Settings } from "@material-ui/icons";
import { logout } from "../../context/authContext/AuthActions";
import { AuthContext } from "../../context/authContext/AuthContext";



export default function Topbar() {
  const {dispatch} = useContext(AuthContext);
  return (
    <div className="topbar">
      <div className="topbarWrapper">
        <div className="topLeft">
          <span className="logo">Admin Page</span>
        </div>
        <div className="topRight">
          
          
          

          
          <button onClick={()=> dispatch(logout())}>Logout</button>
        </div>
      </div>
    </div>
  );
}
