import firebase from "firebase/compat/app"
import { getStorage } from "firebase/storage";

import "firebase/compat/storage"

const firebaseConfig = {
    apiKey: "AIzaSyC6d9_U2BA57Y876tlPpYCy6UAoIE7wV2A",
    authDomain: "ottf-2e9a0.firebaseapp.com",
    projectId: "ottf-2e9a0",
    storageBucket: "ottf-2e9a0.appspot.com",
    messagingSenderId: "141675070393",
    appId: "1:141675070393:web:9f0184b91d09d26ad76c68",
    measurementId: "G-8JDY3F56GG"
  };
  

  firebase.initializeApp(firebaseConfig);
  const storage =getStorage();
  
  
  export default storage;